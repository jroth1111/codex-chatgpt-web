# Targeted P1 approval review — Russell

Agent: 01a0fc6f-0ebe-7212-98a6-e508368c99ac
Model: Web GPT-5.6 Sol xhigh; fresh; read-only; no delegation; closed after final report.
Reviewed intended tree: c1599da82e3bd860593fbe92bf0b88265369eb21.
Post-restart source: canonical; launcher31964 / daemon65848.

修正後的覆核結論如下。上一輪有幾個輔助查詢**沒有執行並取得 Native 結果**；其原因未確認，我不再將它們歸因於安全、權限、審批或政策因素。後續所需資訊已由其他成功的 Native 讀取補齊，因此不影響審查結論。

**原 confirmed P1 blocker 已解除。未確認到新的 P0 / P1 / P2。**

- src/adapters/chatgpt-web/browser-worker.ts 的修正建立共用 notifyApprovalPending closure，並傳給兩個 resolveChatGptToolConfirmation callsite：Enhanced tunneled observe 路徑與一般 DOM 路徑。Native diff 明確顯示原先 tunnel callsite 缺少 callback，而 intended tree 已補上。
- callback 傳送目前 turn 的 traceId 與 process.pid。launcher/electron/browser-host.cjs 的 setTurnApprovalPending() 會先經 heartbeatTurn(traceId, helperPid) 驗證 owner，再要求 tab 為 running 且 automatic。既有 launcher/tests/control-server.test.cjs 也驗證錯誤 helper PID、其他 tab、terminal tab 與 manual mode 均不會取得 approval state。
- pending approval 只暫時解除該 running owner 的 interaction shield。BrowserHost 的 syncViewVisibility() 條件為 approvalPending === true 時隱藏 shield；interactionLocked 本身沒有被永久修改。focusActiveSurface() 在 pending 時聚焦實際 ChatGPT view，清除後回到 shield。
- resolveChatGptToolConfirmation() 的 manual 分支在 finally 一律呼叫 onApprovalPending(false)。Native source 顯示 acceptance、60 秒 deadline 後 Deny、abort/error 都經過此 cleanup。turn 結束時 BrowserHost 也會再次把 approvalPending 清成 false。
- auto-approval 行為沒有擴張：matcher 是 ^Allow(?: once)?$，只接受 Allow / Allow once。既有 contract test 顯示 Always allow 會得到「Approval button not found」，因此永久授權語意沒有被改變。
- 新增的 browser-tunneled-fallback.test.ts composed fixture 同時跑 untunneled=false/true，每條都涵蓋 acceptance、timeout、abort，並驗證 pending 序列為 \[true,false\]、shield 恢復、interactionLocked 保持 true、另一個 tab 沒有 approvalPending。舊版 RED Native log 顯示通知陣列實際為空；修正後 boundary log 為 **2 pass / 0 fail / 120 assertions**。
- focused Native log為 **234 pass / 0 fail / 1941 assertions**；audit log為 **4 pass / 0 fail / 1431 assertions**；lifecycle log顯示 shared suite **588 pass / 1 既有 skip / 0 fail**。
- C 的 Native Git 輸出確認雙親為 B=3efe80067f474daeb870ff6b2344f14ccfdd9b37 與 U=b6ca2d3f91f8a2ba140b522fe3b3c50b4ebffa2d；c1599da82e3bd860593fbe92bf0b88265369eb21 確認為 tree。四個指定變更檔相對 candidate 的 git diff --quiet 回傳 0。
- evidence archive 的 Native 結果確認大小 **1,214,140 bytes**，SHA-256 為 c3444304d5be357b44a29816a6e873ff03f9de97408220f198621f31010725d8，與 ledger 更新一致。

驗證限制仍需保留：目前沒有真實 ChatGPT approval card 的 live 驗證。新增 composed test 對 launcher notifier 使用 spy，因此單一測試本身沒有穿過真實 HTTP control endpoint；HTTP owner 驗證與 tab 隔離、BrowserHost shield/focus 則由既有 production-path launcher tests 分別覆蓋。這是**驗證邊界限制，不是 confirmed defect**。

因此 reviewer 結論維持：**P1 已關閉，沒有新的 confirmed P0/P1/P2，這個修正目前可通過獨立審查。**

## Parent delivery observation

At 2026-10-02T11:58:30.070Z trace ff04cd69d12b recorded `output recovery path=dom reason=tunnel_final_missing`; browser settlement followed at 11:58:32.820Z with outcome=final, compaction=false, submission=accepted. The review report arrived in full and the agent was closed. This is successful code-review delivery through the existing DOM fallback, not evidence of a successful Native final control. No assertion is made that the auxiliary omitted queries executed or that their cause was policy, authorization, or a local channel defect. There is no live ChatGPT approval-card acceptance claim. Post-close daemon remains healthy/accepting/idle.

