# upstream v6.1.4 continuing merge — 唯讀審查報告

審查日期：2026-10-02  
Repository：`G:\codex-chatgpt-web`  
Candidate：`0315600588f0f0c7053d4abd9ad78ee5e24adc0d`  
Tree：`91d2fb0351840711601a024d6f23cc370bbae71b`

## 結論

本次找到 **1 個 confirmed P1 / 高嚴重度問題**。我會把它視為 **v6.1.4-Enhanced.1 發布前 blocker**，因為它落在預設 Enhanced Automatic 設定，且一旦 ChatGPT 顯示 connector tool approval，使用者在預設 interaction shield 下無法完成手動核准，60 秒後程式會主動按下 `Deny`。沒有發現 P0；除這一項外，也沒有確認第二個 upstream omission、ABI/security regression、race/deadline/cleanup defect 或測試弱化。

## Confirmed findings

### P1 / High / Release blocker — Enhanced output tunnel 遺漏 manual approval pending callback，預設互動鎖會讓核准 UI 不可操作並在 60 秒後 Deny

**位置**

- `src/adapters/chatgpt-web/browser-worker.ts:595-647`：`resolveChatGptToolConfirmation` 的 manual approval path 只有在收到 `onApprovalPending` 時才會通知外部；`626` 設為 `true`，`647` 清為 `false`，timeout 常數在 `263` 為 60,000 ms。
- `src/adapters/chatgpt-web/browser-worker.ts:4778-4935`：`turn.tunneledOutput` 分支在 `4930-4935` 呼叫 `resolveChatGptToolConfirmation`，但沒有傳第七個 `onApprovalPending` callback。
- `src/adapters/chatgpt-web/browser-worker.ts:5155-5169`：一般 DOM observation 分支有正確傳 callback，並送出 `phase: "approval"`、同一 `traceId` 與 `helperPid`。
- `src/config.ts:98,117,470` 與 `launcher/electron/state.cjs:17,20,31`：預設為 `useEnhancedOutputTunnel=true`、`autoApproveToolCalls=false`、`lockBrowserDuringTurns=true`。
- `src/adapters/chatgpt-web/native-output-control.ts:31-45`：Automatic Native2、有 local tools、有 tools、非 Luna/compaction/manual/checkpoint 的正常 Enhanced tool turn 會使用 tunnel。
- `launcher/electron/browser-host.cjs:1284-1293,1414-1422,1511-1524`：launcher 只有在 owning running tab 的 `approvalPending===true` 時才暫時解除 interaction shield 並把 focus 給實際頁面。
- `launcher/electron/control-server.cjs:264-269`：`/v1/turn/approval` 才會把這個狀態送進 `setTurnApprovalPending`。

**Trigger**

使用預設 Automatic Enhanced 設定，Native2 connector turn 進入 Enhanced output tunnel，ChatGPT 顯示 `Allow ChatGPT to use <app>?` approval card/dialog，且使用者維持預設 `autoApproveToolCalls=false` 與 `lockBrowserDuringTurns=true`。

**證據**

`resolveChatGptToolConfirmation` 在 manual 模式會先等待 dialog 消失；若 60 秒內仍可見，`browser-worker.ts:636-640` 會找到精確 `Deny` 並按 Enter。一般 DOM 分支會在等待期間送出 launcher approval state，但 tunnel 的 `observe` callback 完全沒有這個參數，因此 launcher 永遠不會知道 approval pending。

B..C diff 也確認：這次 merge 新增了 `onApprovalPending` 參數與一般 DOM call-site wiring，但既有 tunneled call-site 沒有同步接線，屬於本次功能整合缺口。

現有測試各自驗證了局部元件，但沒有跨過這個接縫：

- `tests/browser-worker-contract.test.ts:2299-2363` 直接測 helper 的 pending true/false、timeout Deny、cancel、Allow once 與非 dialog card。
- `launcher/tests/tool-approval-lock.test.cjs:25-50` 測 selected owner 解鎖、恢復 shield，以及 standby Fast page 不得成為 approval surface。
- `launcher/tests/control-server.test.cjs:56-102` 測 owner/token/status/manual-mode 驗證與跨 tab 隔離。
- tunnel 相關測試存在，但沒有測「tunneled observation 看見 approval → launcher phase=true/false → shield 可互動」這條完整路徑。

因此目前的綠燈不會捕捉這個問題。

**影響**

需要人工同意的 connector tool call 在預設 Enhanced 路徑會顯示 approval UI，但互動 shield 仍覆蓋頁面，launcher 也不會顯示 waiting approval notice。使用者無法從預期 UI 完成 Allow/Deny；等待 60 秒後 worker 會自動 Deny。這會使需要 permission prompt 的工具呼叫被拒絕，並造成近一分鐘的假性停滯。

若使用者關閉 interaction lock、或明確開啟 `autoApproveToolCalls`，此 trigger 可避開；但這兩者都不是預設設定，因此不能視為可接受的發布條件。

**修正方向**

把 owner-bound approval notifier 提升成共享 helper/closure，讓 **tunneled 與一般 DOM 兩個 call site 都傳入完全相同的 `onApprovalPending` callback**。保留目前 `traceId/helperPid` ownership 驗證、running-only / automatic-only 限制，以及 `/^Allow(?: once)?$/` 的 one-time approval matcher，不要放寬成 permanent permission。

新增一個 tunnel regression test，至少驗證：

1. tunneled branch 看見 manual approval 時送 `pending=true`；
2. dialog 消失、取消、timeout/cleanup 時一定送 `pending=false`；
3. 只有同 owner 的 running selected tab 可解除 shield；
4. standby Fast page 與其他 owner 不受影響；
5. auto-approve 仍只允許 `Allow` / `Allow once`，不匹配 `Always allow`。

## Hypothesis / 未證實事項

沒有保留其它 code-defect hypothesis。其餘未覆蓋項目列在「未驗證邊界」，屬平台或真實 UI 驗證範圍，不是我目前認定的缺陷。

## 實際檢查範圍

我核對了 candidate identity 與 merge topology：HEAD、tree 均與指定 C 一致；C 的雙親精確為 B/U；`073be0f847f58e298ab1a6db10bdb2e47464af07` 仍可解析為 tree；v6.1.4 annotated object 仍為 tag。工作樹在報告寫入前只有使用者原有的 `.gitignore` 修改，未碰觸。

B..C 共 **84 個變更檔案**；P..U 共 **57 paths / 214 default-context hunks**。權威 ledger 為 schema 3，coverage 為 57 paths、214 hunks、20 test paths、60 個宣告 test-case delta、pending 0、missing 0。路徑分類為 51 adapted / 6 exact；hunks 為 203 adapted / 11 exact；60 個宣告案例為 20 adapted / 32 exact / 8 superseded。參數化測試仍依實際 runtime 展開，沒有把「60 宣告」誤當作「60 runtime tests」。

`tests/upstream-audit-v613.test.ts:191-210` 會逐 path 以 default `git diff --no-ext-diff --no-textconv` 重建每個 hunk、正規化換行後雜湊，並要求與 ledger 精確相等；我另行以同一 diff 語意確認為 214 hunks。使用 `--unified=0` 會改變鄰近 change 的 hunk 分割，因此不作為 ledger 的 hunk 定義。

特別核對了 P..U 中未直接出現在 B..C path list 的上游檔案與 fork 對應：`launcher/bun.lock`、`launcher/tests/browser-host.test.cjs`、`src/adapters/chatgpt-web/index.ts`、`src/adapters/chatgpt-web/mcp-server.ts`、`src/version.ts`、`tests/environment.test.ts`、`tests/retained-compaction.test.ts`。其語意分別落到 fork 的 dependency/security lock、launcher preference tests、capability retirement / enhanced compaction、MCP invocation retirement metadata、root package version authority、midnight steering、retained compaction handoff/settlement 實作與測試。除上述 approval tunnel wiring 外，沒有找到缺漏。

逐項語意審查結果：

- connector/Think 與 multipart：每個實體 message 都重新驗證 connector 後再設 Think；413 submission rejection 會終止後續 stage，已送出的 stage/ack 不重送。
- Markdown：KaTeX 以唯一 `application/x-tex` annotation 作語意 identity，保留精確 TeX；code/pre 排除正確；重複段落採有序唯一索引且 ambiguity fail-closed。
- broker retirement：local/remote timeout failure metadata 有 schema 驗證；`codex_tool_timeout` 轉為 504 `server_error`、`retryable=false`，並保持 owner-bound retirement。
- compaction：source physical settlement 與 retained/fresh checkpoint 各自有獨立 deadline budget；retained handoff 傳 model family；cleanup/physical retirement 有測試；already-aborted promise 也被 ownership 處理。
- steering：current native rollout 才能擴充 writable-root authority，ordinary steering 只能是已證明 writable roots 的 subset；cwd/roots/sandbox/network 衝突 fail closed。
- model / limits / account trust：active picker evidence 限定 active menu/header，future/versionless/conflicting/foreign/inactive evidence fail closed；limits 在操作前後重驗 account/plan。
- launcher approval/progress：除了 tunnel call-site 缺口外，IPC opt-in、偏好 transaction/migration、owner-bound progress、same-owner shield、standby 禁止 approval 的局部實作皆一致。
- updater：HTTPS redirect、no-cookie、manual redirect、header/body stall timeout、chunk re-arm、response body cancel、`wx` exclusive create、failure/cancel temp cleanup 均有實作與測試。
- CDP：`noDefaults:true`，只對已驗證 owned target 啟用 focus emulation；不污染 unrelated page。
- interrupt：只接受與既有 ownership/command/order/timeout 相同的 native explicit defaults；行為改變會 fail closed。
- ABI / preserved fork behavior：Native2 public connector contract 檔 `src/adapters/chatgpt-web/connector-contract.ts` 在 B..C 沒有變更；Enhanced context-limit implementation 與 B 相同；passive periodic recovery checkpoint 仍受 `experimentalNoAutoCompact===true` 限制；Fast startup lease/TTL/ownership 與 Enhanced retention 的核心常數/語意沒有被本次 diff 改寫。

## 既有證據重用

沒有重跑整套 gates 或 account tests。

- `verify-final.log`：root runner 覆蓋 **310 個 test files**；root/launcher typecheck、root/launcher audit、launcher tests、renderer build、runtime bundle 與 isolated relocatable smoke 均完成；launcher summary 為 **618 pass / 6 existing skip / 0 fail**，最後有 `RELOCATABLE_RUNTIME_SMOKE_OK`。
- `lifecycle-all-cached.log`：Codex / Claude / Pi / shared deterministic lanes 完成；shared summary **586 pass / 1 existing skip / 0 fail**，最後為 `ALL_DETERMINISTIC_LIFECYCLE_LANES_OK`。
- `real-dom-first.log`：system Chrome 真實 headless DOM **7 pass / 0 fail**，覆蓋 model-family active picker evidence 與 launcher CDP native appearance/focus。
- `audit-final-green.log`：**4 pass / 0 fail / 1407 assertions**，包含 continuing v6.1.4 archive closure 與 bare-repo reconstruction。
- `.github/upstream-audit/v6.1.4-evidence.tar.gz`：實際 **1,156,418 bytes**，SHA-256 精確為 `1347cf4ddf9fe9eec838fd8b17e1bb1045d1794550c4f900aff77d20f19bbc7c`。

這些證據能證明機械 closure 與大量 deterministic behavior，但不能取代本次抓到的 tunnel/manual-approval 語意接縫。

## 保留邊界

- Native2 public contract/schema/description/hash 所在 contract surface 在 B..C 未變。
- Enhanced normal context-limit implementation未變；No Context Window 的 private recovery checkpoint gate 仍只在對應實驗設定開啟時作用。
- Passthrough、Fast startup 的核心 concurrency/TTL/ownership，以及既有 Enhanced retention 未發現本次 merge 改寫。
- 四份 README 的 download links 仍指向 fork `releases/latest`，並明確標示 `6.1.4-Enhanced.1` 為 development candidate、尚未發布。
- `scripts/install.sh:5` 仍預設 `6.1.3-Enhanced.1`。
- candidate C 本地沒有 tag 指向；`.gitignore` 使用者修改未碰觸。

## 未驗證邊界

本次沒有重新跑 macOS/Linux packaged launcher、真實跨平台 updater install、真實 ChatGPT approval card + launcher shield 的互動式 account test，也沒有重跑完整 live lifecycle/account tests。現有 real-DOM 7 tests 只覆蓋 model picker 與 CDP system-theme/focus，不涵蓋本 finding 的 approval UI。

PR #62、遠端是否已 push、遠端 tag/release 狀態沒有在本地唯讀審查中另行連網驗證；本地只確認 candidate C 沒有 tag 指向，README/installer 仍維持未發布候選與 6.1.3-Enhanced.1 installer 邊界。

## 最終判定

**目前不建議把 C 直接作為 v6.1.4-Enhanced.1 發布候選完成發布。** 先修正 tunneled-output approval pending wiring 並補一條跨 tunnel → launcher owner/shield 的回歸測試；其餘 reviewed upstream v6.1.4 semantics 與 fork adaptations 未發現 confirmed omission。
