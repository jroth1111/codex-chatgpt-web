import { expect, test } from "bun:test";
import { chatGptHtmlToMarkdown } from "./candidate/src/adapters/chatgpt-web/markdown";

test("v6.1.4 preserves a single original LaTeX source instead of duplicated rendering", () => {
  const html = '<p>Inline: <span class="katex"><span class="katex-mathml"><math><semantics>'
    + '<mrow><mi>ACCESSIBLE_COPY</mi></mrow><annotation encoding="application/x-tex">E = mc^2</annotation>'
    + '</semantics></math></span><span class="katex-html" aria-hidden="true">VISUAL_COPY</span></span>.</p>';
  expect(chatGptHtmlToMarkdown(html)).toBe(String.raw`Inline: \(E = mc^2\).`);
});
