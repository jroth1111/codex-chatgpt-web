覆核結果：**Confirmed P0 / P1 / P2 均為 0；沒有 blocker。這組 candidate 不阻擋推送到 `main` 以取得新一輪 CI。** 這個結論不等於 hosted CI 已經轉綠，也不等於 release gate 已完成。

我覆核了 `a7d455a60a361b52aed0b3097a479368c5a37a78` → intended tree `65f75ec260d167af31c339a1efaaae79a744f5a8` 的精確六檔差異及必要依賴。Index 與 intended tree 相符；使用者既有 `.gitignore` 仍是另外一個 unstaged 修改，沒有包含於 candidate；`git diff --check` 無異常。

核心 `runExclusive` 修正沒有發現 ordering/cleanup/coalescing/rejection/deadline regression：

- `src/adapters/chatgpt-web/browser-worker.ts:3911-3930` 現在保存實際 in-flight heartbeat Promise。活動期間仍維持單一 in-flight；重複觸發只設 `heartbeatPending`，settle 後至多補一次。
- `src/adapters/chatgpt-web/browser-worker.ts:3983-4000` 的 terminal 順序是 `activityFinished = true` → clear interval → await 當前 heartbeat → prepared transport cleanup → `end`。因為 `activityFinished` 已先設為 true，既有 pending heartbeat 在 `.finally()` 再呼叫 `sendHeartbeat()` 時會直接返回，因此不會在 terminal cleanup 後再產生 heartbeat。
- heartbeat rejection 仍由原本的 `.catch()` 吸收；finished 後連 warning 都不再產生，因此新增的 `await heartbeatInFlight` 不會用 heartbeat failure 覆蓋 browser 原始錯誤。`tests/browser-startup-continuation.test.ts:149-180` 另外直接驗證回傳的仍是同一個 original error object。
- `src/launcher-browser-host.ts:388-465` 顯示 heartbeat timeout 仍為 **5 秒**、heartbeat interval 10 秒、end timeout 15 秒；沒有改 deadline 常數。這個修正最多增加既有 5 秒 bounded settlement 等待，沒有形成無界等待。
- `runWithSurfaceRetry` 的兩個 caller（`browser-worker.ts:1235`、`:1254`）都經過相同 `runExclusive` terminal contract；retry eligibility、Native2 ABI、context/checkpoint contract 都未被這次 diff 改變。
- 原本 end control failure 對 browser error 的保留邏輯仍在 `browser-worker.ts:4014-4023`；只有既有的明確 user-cancel/sign-in terminal signal 可以覆蓋，這次修改沒有改該政策。

TDD 證據與首輪 CI failure 能形成直接因果鏈：`heartbeat-red.log` 在舊 source 實際得到 `start,end`，而 held heartbeat 尚未 settle；candidate 的 focused green 則得到 `start,heartbeat,end` 且保留 original failure。首輪 Ubuntu CI 也實際記錄了 `start,end,heartbeat` 的錯序。因此這不是僅靠 mock 推測出的修正。

三個 fixture 變更也沒有發現 confirmed defect：

- `tests/browser-tunneled-fallback.test.ts:19-26` 使用與既有 `browser-authentication-failure.test.ts` 相同的 VM loader，載入真實 `BrowserHost`，只替換 `electron` import boundary。首輪 root-only lifecycle 的實際 failure 正是直接 `require` 導致 `Cannot find package 'electron'`；focused candidate 測試已綠。
- `tests/environment-rollout.test.ts:89-101` 只把原本相同 schema/rows 的 SQLite fixture writes 放入一個 transaction；assertions 與 5 秒 timeout 沒改，資料仍在 `database.close()` 前 commit。
- heartbeat regression 本身具有有效 RED；沒有看到新增 skip、弱化 assertion 或為取得綠燈改 timeout。

既有 gate 證據身份也一致：`heartbeat-and-sqlite-green.log` 38 pass / 140 assertions；`ci-fix-focused.log` 9 pass / 170 assertions；`verify-ci-fix.log` 是正常 verify 流程；`lifecycle-ci-fix.log` 最終為 589 pass / 1 個既有 skip / 0 fail / 4723 assertions，並有 `ALL_DETERMINISTIC_LIFECYCLE_LANES_OK`；`audit-ci-gated.log` 4 pass / 1461 assertions。我依要求重用這些證據，沒有重跑 full gates。

Audit bundle 亦一致：candidate `v6.1.4-evidence.tar.gz` 實際 SHA-256 為 `89283913cdd064ac806a698bf1f8f33c206444f3914f7e384d17c5b0e5a13dc1`、1,346,841 bytes，與 `v6.1.4.json` 完全相符。原始 `current/original-merge/*`、objects pack、prior ledger/tag material 的 manifest hash 未改；更新後 `resolution-vs-B.patch` 包含本輪四個 source/test path，且明確不含 `.gitignore` 或 `AGENTS.md`。

**Hypotheses / 尚待外部驗證，非 confirmed finding：**

1. **Windows physical/hosted runner 仍必須由新 CI 驗證。** 第一輪 Windows log 只能確定兩個既有 SQLite filesystem case 分別耗時約 6.36 秒與 7.51 秒而撞上原 5 秒 timeout，沒有 assertion mismatch。把 writes 合併進 durable transaction 是合理且本機證據良好，但目前不能由本機結果宣稱 Windows runner 根因已經被證實修復。這不阻擋把 candidate 推上 `main` 取得該必要證據；在新 Windows job 綠之前，不應宣稱此平台 gate 已關閉。
2. 新的 root-only `BrowserHost` VM loader 也仍待 candidate 的 hosted Linux CI 最終確認。它與同一 suite 中已使用的既有 loader 模式一致，且 focused/local gates 已通過，所以目前沒有足以構成 blocker 的反證。

因此本次 reviewer verdict 是：**無 confirmed P0/P1/P2，允許進入 main CI push 階段；後續 acceptance 必須保留 fresh Windows physical runner（以及相應 hosted Linux）結果作為仍未取得的 hosted evidence。**
